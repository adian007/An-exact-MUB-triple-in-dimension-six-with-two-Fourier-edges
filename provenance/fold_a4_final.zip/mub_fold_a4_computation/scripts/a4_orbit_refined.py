import json, numpy as np
LAM=0.1114802243779665542913031975274172717685818097497045
R=json.load(open('/mnt/data/mub_fold_a4_computation/results/refined_singular_roots.json'))
R=[x for x in R if x['F_norm']<1e-7 and x['J_u_norm']<1e-7 and x['norm_err']<1e-8]
sols=np.array([x['a'] for x in R])
G2=np.array([[1,0,0,0,0,0],[0,0,0,1,0,0],[0,0,1,0,0,0],[0,1,0,0,0,0],[0,0,0,0,0,1],[0,0,0,0,1,0]],complex)
z=np.exp(1j*LAM)
G3=np.array([[0,-1,0,0,0,0],[0,0,0,0,z,0],[0,0,0,-1j,0,0],[0,0,0,0,0,-z],[1,0,0,0,0,0],[0,0,1j,0,0,0]],complex)

def canon(v):
 v=v/v[0]
 return np.angle(v[1:])
def keydist(a,b): return np.linalg.norm(np.angle(np.exp(1j*(a-b))))
def orbit(a):
 seen=[]; q=[a]
 while q and len(seen)<30:
  x=q.pop(0)
  if any(keydist(x,y)<2e-6 for y in seen): continue
  seen.append(x)
  v=np.r_[1,np.exp(1j*x)]
  q.extend([canon(G2@v),canon(G3@v)])
 return seen
assigned=set(); outs=[]
for i,a in enumerate(sols):
 if i in assigned: continue
 pts=orbit(a); inds=[]
 for p in pts:
  d=np.array([keydist(p,s) for s in sols]); j=int(np.argmin(d)); inds.append((j,float(d[j])))
 valid=[j for j,d in inds if d<1e-5]
 for j in valid: assigned.add(j)
 outs.append({'seed':i,'orbit_size':len(set(valid)),'max_match_error':max(d for j,d in inds),'indices':sorted(set(valid)),'matches':inds})
print('n good',len(sols),'orbits',[(o['orbit_size'],o['max_match_error']) for o in outs])
# generator permutation on all roots
perms=[]
for name,G in [('G2',G2),('G3',G3)]:
 p=[]; errs=[]
 for a in sols:
  w=canon(G@np.r_[1,np.exp(1j*a)])
  d=np.array([keydist(w,s) for s in sols]); p.append(int(np.argmin(d))); errs.append(float(np.min(d)))
 perms.append({'name':name,'perm':p,'max_error':max(errs)})
print(perms)
json.dump({'n_good':len(sols),'orbits':outs,'generator_permutations':perms},open('/mnt/data/mub_fold_a4_computation/results/a4_refined_orbits.json','w'),indent=2)
np.savetxt('/mnt/data/mub_fold_a4_computation/results/refined_24_roots.csv',sols,delimiter=',')
