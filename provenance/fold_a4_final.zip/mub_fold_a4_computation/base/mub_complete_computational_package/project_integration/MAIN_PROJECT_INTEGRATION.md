# Integrating into the Main MUB Repository

Recommended structure:

    MUB/
      src/
        exact/
          dita.py
          dita.jl
        mub_pool/
        symmetry/
        fourth_mub/
      symbolic/
        I3/
        I4/
      computations/
        pool/
        continuation/
        fold/
        orbit/
      results/
        certified/
        numerical/
      docs/
        research/
        reproducibility/
      tests/

## Suggested placement

Copy the contents of `01_symbolic_I3/` into `symbolic/I3/` first. Then move the exact Diţă formulas into the repository's canonical exact-family module instead of maintaining two independent definitions.

The generated text files should remain under `results/` or `docs/` if they are outputs, while Python source stays under `symbolic/` or `src/`.

## Do not merge blindly

Before replacing existing project files:

- compare matrix conventions and indexing;
- check whether the repository uses normalized or unnormalized Hadamard matrices;
- check whether row/column permutations are zero-based or one-based;
- check the convention for permutation matrices;
- preserve exact algebraic coefficients;
- preserve random seeds and tolerances for numerical experiments.

## Canonical convention

All mathematical matrix indices in the research documentation are 1..6. Python list indices are naturally 0..5. The Diţă equivalence certificate uses row source list r=(1,6,2,3,5,4), column source list c=(2,3,5,4,6,1), and row phase R=diag(1,-i,-1,-i,i,i), with R applied after the row/column permutations.

## First validation after integration

Run:

    python symbolic/I3/build_i3.py

Then compare the regenerated I3_stats.txt with the packaged version. Next run the symmetry tests. Only after these pass should the package be connected to numerical pool extraction.
