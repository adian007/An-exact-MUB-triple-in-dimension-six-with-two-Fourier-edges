# Reproducibility Guide

## Python symbolic environment

Recommended Windows setup:

    conda create -n mub-symbolic python=3.11 sympy numpy
    conda activate mub-symbolic

Then run from the package root:

    python 01_symbolic_I3/build_i3.py

If the project's existing environment already contains SymPy, use it rather than creating a duplicate environment.

## Julia numerical algebraic geometry

Install Julia and add HomotopyContinuation.jl in the Julia REPL:

    using Pkg
    Pkg.add("HomotopyContinuation")

The official documentation describes polynomial systems, parameter homotopies, mixed-volume starts, continuation, and certification: https://www.juliahomotopycontinuation.org/HomotopyContinuation.jl/stable/

For this project, record Julia version, package versions, random seeds, parameter values, tolerances, and whether certification was used. This is especially important for the 252-path witness computations.

## Exact CAS

The project may use Macaulay2, Mathematica, SageMath, or SymPy depending on the subproblem. Exact coefficient fields must be written explicitly. Never silently replace an algebraic coefficient by a floating-point approximation when claiming an exact ideal computation.

## Reproduction checklist

1. Verify the exact H_D(z) matrix.
2. Regenerate I3_single_vector.txt.
3. Compare generator counts and term counts with I3_stats.txt.
4. Re-run exact conjugation symmetry tests.
5. Re-run the fixed-z monomial search at the documented generic sample.
6. Verify every discovered monomial automorphism symbolically.
7. Recompute the A4 closure/order.
8. Run the actual B3 orbit decomposition before interpreting singular roots.
9. Re-run fold detection with logged precision/tolerances.
10. Only then attach the fourth-vector ideal and run certification.
